<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Migrations\Session;
use App\Item;
use App\Uom;
use Cart;


class CartController extends Controller
{
    function add_to_cart(Request $request){
    	$id = $request->id;
    	$item_id = $request->cmbItem;
    	$uom_id = $request->cmbUOM;
    	$qty = $request->txtQty;
    	$price = $request->txtPrice;

    	$data['id'] = $id;
    	$data['name'] = $item_id;
    	$data['qty'] = $qty;
    	$data['price'] = $price;
    	$data['options']['uom'] = $uom_id;

    	Cart::add($data);
    	return redirect()->route('order.create');
    }
}
