<?php
Route::get('/','HomeController@index')->name('welcome');

Route::post('/reservation','ReservationController@reservation')->name('reservation');
Route::get('send', 'MailController@send')->name('send');


Auth::routes();
Route::group(['prefix'=>'admin','middleware'=>'auth','namespace'=>'admin'], function(){
	Route::get('dashboard', 'DashboardController@index')->name('admin.admin-dashboard');
	Route::resource('slider', 'SliderController');
	Route::resource('employee', 'EmployeeController');
	Route::resource('category', 'CategoryController');
	Route::resource('item', 'ItemController');
	Route::resource('supplier', 'SupplierController');
	Route::resource('role', 'RoleController');
	Route::resource('uom', 'UomController');
	Route::resource('order', 'OrderController');
  	Route::resource('kitchen', 'KitchenController');
	Route::get('cart', 'CartController@create')->name('cart.create');
	Route::post('admin/cart', 'CartController@add_to_cart')->name('cart.add');
	Route::resource('reservation', 'ReservationController');
	
});