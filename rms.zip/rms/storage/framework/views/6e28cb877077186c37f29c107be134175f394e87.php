<?php $__env->startSection('title','Create Order'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-title">
  <div>
    <h1><i class="fa fa-edit"></i> Reservation Confirmation</h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item">Reservation</li>
    <li class="breadcrumb-item"><a href="#">Reservation Confirmation</a></li>
  </ul>
</div>
    <div class="tile">
      <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?php echo e($error); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <h3 class="tile-title">Confirmation</h3>
      <form class="form-horizontal" action="<?php echo e(route('reservation.update',$reservation->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
      <div class="form-group row">
        <label class="control-label col-md-3">Reservation Confirmation</label>
        <div class="col-md-9">
          <div class="form-check">
            <label class="form-check-label">
              <input class="form-check-input" type="radio" name="txtStatus" value="true">Yes
            </label>
          </div>
          <div class="form-check">
            <label class="form-check-label">
              <input class="form-check-input" type="radio" name="txtStatus" value="false">No
            </label>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="col-md-8" style="margin-right: 45px;"></div>
          <div class="col-md-3">
            <a class="btn btn-secondary" href="<?php echo e(route('reservation.index')); ?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>&nbsp;&nbsp;&nbsp;<button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Confirme</button>
          </div>
        </div>
    </form>
    </div>
<div class="clearix"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>