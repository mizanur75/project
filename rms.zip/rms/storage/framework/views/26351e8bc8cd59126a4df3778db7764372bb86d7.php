<?php $__env->startSection('title', 'Category'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
      <h1><i class="material-icons">slideshow</i>All Categories</h1>
      <!--p>Table to display analytical data effectively</p-->
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Slider</li>
      <li class="breadcrumb-item active"><a href="#">All Sliders</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <?php if(session('msg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('msg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <?php if(session('umsg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('umsg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <?php if(session('dmsg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('dmsg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <div class="tile">
        <div class="tile-body">

          <table class="table table-hover table-bordered table-sm" id="sampleTable">
          	<a href="<?php echo e(route('category.create')); ?>" class="btn btn-sm btn-primary">Add New</a>
            <hr>
            <thead>
              <tr>
                <th>SL</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Created At</th>
                <th class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
       			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       				<tr>
       					<td><?php echo e($key + 1); ?></td>
       					<td><?php echo e($category->name); ?></td>
       					<td><?php echo e($category->slug); ?></td>
       					<td><?php echo e($category->created_at); ?></td>
       					<td class="text-center"><a class="btn btn-sm btn-info" href="<?php echo e(route('category.edit',$category->id)); ?>"><i class="fa fa-edit"></i></a>
                  <form action="<?php echo e(route('category.destroy',$category->id)); ?>" method="post" style="display: inline;" onsubmit="return confirm('Are you Sure? Want to delete')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-danger" type="submit" ><i class="fa fa-trash"></i></a></button>    
                </form></td>
       				</tr>
       			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('back/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('back/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>