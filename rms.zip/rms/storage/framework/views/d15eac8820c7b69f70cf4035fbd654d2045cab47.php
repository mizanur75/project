<?php $__env->startSection('title','Reservation Details'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-title">
    <div>
      <h1><i class="material-icons">supervisor_account</i>All Reservation</h1>
      <!--p>Table to display analytical data effectively</p-->
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Reservation</li>
      <li class="breadcrumb-item active"><a href="#">All Reservation</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <?php if(session('msg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('msg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <div class="tile">
        <div class="tile-body">

          <table class="table table-hover table-bordered table-sm" id="sampleTable">
            <thead>
              <tr>
                <th width="2%">SL</th>
                <th width="18%">Name</th>
                <th width="5%">Phone</th>
                <th width="7%">Email</th>
                <th width="12%">Reserve Date</th>
                <th width="13%">Message</th>
                <th width="7%">Status</th>
                <th width="12%" class="text-center">Reservation On</th>
                <th width="14%" class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
       			<?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       				<tr>
       					<td><?php echo e($key + 1); ?></td>
       					<td><?php echo e($reservation->name); ?></td>
       					<td><?php echo e($reservation->phone); ?></td>
       					<td><?php echo e($reservation->email); ?></td>
       					<td><?php echo e($reservation->date); ?></td>
                <td><?php echo e($reservation->message); ?></td>
                <td>
                  <?php if($reservation->status == true): ?>
                    <span class="btn btn-sm btn-success">Confirmed</span>
                  <?php else: ?>
                    <span class="btn btn-sm btn-danger">Not Confirmed</span>
                  <?php endif; ?>
                </td>
       					<td><?php echo e($reservation->created_at); ?></td>
       					<td class="text-center">
                  <?php if($reservation->status == false): ?>
                 <form action="<?php echo e(route('reservation.update',$reservation->id)); ?>" method="post" style="display: inline;" onsubmit="return confirm('Are you confirmed by phone this reservation?')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-check"></i></a></button>    
                </form>
                <?php endif; ?>
                <form action="<?php echo e(route('reservation.destroy',$reservation->id)); ?>" method="post" style="display: inline;" onsubmit="return confirm('Are you sure? want to delete')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a></button>    
                </form></td>
       				</tr>
       			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('back/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('back/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script>
  $('#sampleTable').DataTable();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>