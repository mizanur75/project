<?php $__env->startSection('title','Employee Details'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-title">
    <div>
      <h1><i class="material-icons">supervisor_account</i>All Employees</h1>
      <!--p>Table to display analytical data effectively</p-->
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">employee</li>
      <li class="breadcrumb-item active"><a href="#">All Employees</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <?php if(session('msg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('msg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <?php if(session('umsg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('umsg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <?php if(session('dmsg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('dmsg')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
      <div class="tile">
        <div class="tile-body">

          <table class="table table-hover table-bordered table-sm" id="sampleTable">
          	<a href="<?php echo e(route('employee.create')); ?>" class="btn btn-sm btn-primary">Add New</a>
            <hr>
            <thead>
              <tr>
                <th width="2%">SL</th>
                <th width="18%">Name</th>
                <th width="5%">Phone</th>
                <th width="7%">Email</th>
                <th width="12%">Pre. Address</th>
                <th width="13%">Per. Address</th>
                <th width="4%">Role</th>
                <th width="4%">Sex</th>
                <th width="5%">Identity</th>
                <th width="12%" class="text-center">Added On</th>
                <th width="14%" class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
       			<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       				<tr>
       					<td><?php echo e($key + 1); ?></td>
       					<td><?php echo e($employee->name); ?></td>
       					<td><?php echo e($employee->phone); ?></td>
       					<td><?php echo e($employee->email); ?></td>
       					<td><?php echo e($employee->pre_address); ?></td>
       					<td><?php echo e($employee->per_address); ?></td>
       					<td><?php echo e($employee->role->name); ?></td>
       					<td><?php echo e($employee->sex); ?></td>
       					<td class="text-center"> <img width="60px" height="60px" style="border-radius: 30px;" src="<?php echo e(asset('uploads/employee/'.$employee->identity)); ?>" alt=""></td>
       					<td><?php echo e($employee->created_at); ?></td>
       					<td class="text-center"><a class="btn btn-sm btn-info" href="<?php echo e(route('employee.edit',$employee->id)); ?>"><i class="fa fa-edit"></i></a>

                 <form action="<?php echo e(route('employee.destroy',$employee->id)); ?>" method="post" style="display: inline;" onsubmit="return confirm('Are you sure? want to delete')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a></button>    
                </form></td>
       				</tr>
       			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('back/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('back/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>