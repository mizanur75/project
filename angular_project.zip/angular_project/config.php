<?php
$base_url="http://localhost/angular_project/";
?>