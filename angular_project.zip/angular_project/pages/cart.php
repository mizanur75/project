<div>
       <table class='table' style="box-sizing:border-box;">
         <tr><th>Remove</th><th>Item</th><th>Qty</th><th>Price</th></tr>
          <tr ng-repeat="item in cart">
             <td><input type="button" class="btn btn-danger" value="Del" ng-click="deleteItem(item.id)" />
             <input type="button" class="btn btn-success" value=" + " ng-click="qtyIn(item)" />
             <input type="button" class="btn btn-warning" value=" - " ng-click="qtyOut(item)" /></td>
             <td>{{item.name}}</td><td>{{item.qty}}</td><td>{{item.price*item.qty}}</td>
          </tr>
          <tr><td colspan="3"><b>{{item.qty+item.qty}}</b></td><td><b>TK: {{total}}</b></td></tr>
        </table>
         <a class="btn btn-primary" id="v-pills-settings-tab" data-toggle="pill" href="#!checkout">Proced to Checkout</a>
</div>