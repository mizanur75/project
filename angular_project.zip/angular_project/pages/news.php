<?php
	$db=new mysqli("localhost","root","","angular_project");
	
	if(isset($_POST["btnSubmit"])){
		
		$mail=$_POST["txtMail"];
		
		$db->query("insert into subscriber(mail)values('$mail')");
		
		if(filter_var($mail, FILTER_VALIDATE_EMAIL)){
			echo "Thank You!";
		}else{
			echo "<span style='color:red;'>Invalid Email!</span>";
		}
	}
	
?>

<nav class="navbar navbar-expand-lg navbar-light bg-danger">
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav mr-auto">
	<button class="btn btn-outline-success my-2 my-sm-0" style="background-color:#000; color:#FFF; margin:0px 10px 0px 185px;">Get News For Update</button>
    <form class="form-inline my-2 my-lg-0" action="#" method="post">
      <input class="form-control mr-sm-2" type="text" name="txtMail" placeholder="Input Email" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="btnSubmit">Submit</button>
    </form>
   </ul>
    <ul class="navbar-nav mr-auto" style="margin-left: 350px;">
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="material-icons">power_settings_new</i></span></a>
        </li>
    </ul>
  </div>
</nav>