<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="horizontal">
  <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#/!" role="tab" aria-controls="v-pills-home" aria-selected="true">Home</a>
  <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#!accesories" role="tab" aria-controls="v-pills-profile" aria-selected="false">Accesories</a>
  <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#!electronics" role="tab" aria-controls="v-pills-messages" aria-selected="false">Electronics</a>
  <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#!others" role="tab" aria-controls="v-pills-settings" aria-selected="false">Others</a>
  <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#!contact" role="tab" aria-controls="v-pills-settings" aria-selected="false">Contact Us</a>
</div>