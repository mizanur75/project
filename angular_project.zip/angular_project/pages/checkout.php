<div class="row">
	<div class="col-md-6">
    	{{message}}
        <form ng-submit="save()">
        <div class="form-group">
        <label>Customer Name</label>
        <input type="text" class="form-control" name="txtCustomerName" ng-model="user.customer_name" />
        </div>
        
        <div class="form-group">
        <label>Phone</label>
        <input type="text" class="form-control" name="txtPhone" ng-model="user.phone" />
        </div>
        <div class="form-group">
        <label>Email</label>
        <input type="text" class="form-control" name="txtEmail" ng-model="user.email" />
        </div>
        
        <div class="form-group">
        <label>Payment Method</label>
        <select class="form-control" name="cmbPaymentMethod" ng-model="user.payment_method">
         <option>VISA Card</option>
         <option>Master Card</option>
         <option>Cupon</option>
         <option>Cash</option>
        </select>
        </div>
        
        <div class="form-group">
        <label>Shipping Address</label>
        <textarea class="form-control" name="txtShippingAddress" ng-model="user.shipping_address"></textarea>
        </div>
        
        <div class="form-group">
        <label>Remark</label>
        <textarea class="form-control" name="txtRemark" ng-model="user.remark"></textarea>
        </div>
        
        
        <div class="form-group">
        <button type="submit" name="btnSubmit" class="btn btn-primary">OK</button>
        </div>
        </form>
    </div>
</div>