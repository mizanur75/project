<div class="row">
<div style="border-right: 2px solid #A00; min-height:400px; margin-top:20px;" class="col-md-8">
<h1 style="color: #6F0000; text-align:center;">Contact Us</h1>
<p class="con">Dhanmondi 15</p>
<p class="con">Keary Plaza, Dhaka 1209</p>

<p class="con"></p>


<p class="con"></p>



<p class="con"></p>


<p class="con"><i class="material-icons">phone</i> +8801710472020</p>

<p class="con"><i class="material-icons">email</i>:mizanurrahman615@gmail.com</p>

</div>
</div>