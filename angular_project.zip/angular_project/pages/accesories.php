<?php
require_once("../config.php");
?>

<div ng-repeat="product in products" class="div">
     <div class="imgfram">
        <div class="img"><img src="<?php $base_url?>img/{{product.photo}}" width="100%" /></div>
     </div>
     <div class="price">
         <div>
         {{product.name}}
         </div>
         <div>
         <b>Tk: {{product.new_price}}</b> <del>  Tk: {{product.old_price}}</del>
        </div>
     </div>
    <div>
     <input type="button" class="buy" id="buy" value="Buy Now" ng-click="addItem(product)" style="margin-left:45px; position:relative;" />
    </div>
</div>