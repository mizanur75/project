<div class="nav flex-column nav-pills">
  <a class="nav-link"  href="#!home" >Home</a>
  <a class="nav-link"  href="#!mobile">Mobile</a>
  <a class="nav-link"  href="#!laptop" >Laptop</a>
  <a class="nav-link"  href="#!settings" >Settings</a>
</div>

