var app = angular.module("myApp",["ngRoute","ngStorage"]);

var base_url="http://localhost/angular_project/";

app.config(function($routeProvider) {
    $routeProvider.when("/", {
		title:"Home",
        templateUrl : "pages/home.php",
		controller : "homeCtrl"
    }).when("/accesories", {
		title:"Accesories",
        templateUrl : "pages/accesories.php",
        controller : "accesoriesCtrl"
    }).when("/electronics", {
		title:"Electronics",
        templateUrl : "pages/electronics.php",
        controller : "electronicsCtrl"
    }).when("/others", {
		title:"Others",
        templateUrl : "pages/others.php",
        controller : "othersCtrl"
    }).when("/checkout", {
		title:"Customer Info",
        templateUrl : "pages/checkout.php",
        controller : "checkoutCtrl"
    }).when("/page4", {
		title:"page4",
        templateUrl : "pages/page4.html",
        controller : "page4Ctrl"
    }).when("/contact", {
		title:"Contact Us",
        templateUrl : "pages/contact.php",
        controller : "contactUsCtrl"
    }).when("/cart", {
		title:"View Cart",
        templateUrl : "pages/cart.php",
        controller : "cartCtrl"
    }).otherwise({redirectTo:'/'});
});

app.run(['$rootScope', function($rootScope) {
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.title = current.$$route.title;
    });
}]);

app.controller("checkoutCtrl", function ($rootScope,$scope,$http,$localStorage) { 
        $scope.user = {};     
        $scope.save = function(){ 
		      $http.post(base_url+"ws/process_checkout.php",$scope.user).then(function(order) { 
				   $http.post(base_url+"ws/process_order_details.php?order_id="+order.data.order_id,angular.toJson($rootScope.cart)).then(function(details) { 
				  $scope.message = "Successully Saved";
				  $scope.user.customer_name="";
				  $scope.user.shipping_address="";				  
				  $scope.user.remark="";
				  $localStorage.cart=[];
				  $localStorage.total=0;	  
		      });		  
		      }); //then end	  	 	 		  
        };//submitForm end		
});

app.controller("rootCtrl", function ($rootScope,$scope,$http) { 
 
});

//--------------Home---------------
app.controller("homeCtrl", function ($rootScope,$scope,$http,$localStorage) { 
	  $http.get(base_url+"ws/home_products_json.php").then(function (response) {
	   $scope.products =response.data;
});
	 $rootScope.qtyIn=function(item){
		 item.qty++;
		 $rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		 $localStorage.total=$rootScope.total;
	 }
	$rootScope.qtyOut=function(item){
		 item.qty--;
		 if(item.qty<=0)item.qty=1		 
		 $rootScope.total=0;
		 angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		$localStorage.total=$rootScope.total;
	}
	if($localStorage.cart==null){
	  $localStorage.cart=[];
	  $localStorage.total=0;
	}
	$rootScope.cart=$localStorage.cart; 
	$rootScope.total=$localStorage.total;
	 $scope.addItem = function (item) {
		 var id=item.id;
		 var name=item.name;
		 var price=item.new_price;     
		 var exists=false;
		
		$rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){		
			if(id==value.id){				
				exists=true;
				value.qty++;				
			}
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
			$localStorage.total=$rootScope.total;
		});	
			
		if(!exists){		
		   var json={'id':id,'name':name,'price':price,'qty':1};	     
		   $rootScope.cart.push(json);
		  $rootScope.total+=parseFloat(price);
		  $localStorage.total=$rootScope.total;
		}
    };//end addToCart
	
	$rootScope.deleteItem=function(item){
		var tmp=$rootScope.cart;
		$rootScope.cart=[];
		$rootScope.total=0;
		 angular.forEach(tmp,function(value,key){ 
			 if(item!=value.id){
				 var json={'id':value.id,'name':value.name,'price':value.price,'qty':value.qty};
				$rootScope.cart.push(json);				
				$rootScope.total+=parseFloat(value.price*value.qty);
			 }
		 });
		 $localStorage.cart=$rootScope.cart;
		 $localStorage.total=$rootScope.total;
	};//DeleteFromCart
});

//=========================End Home Controller===========================================


//========================Start Accesories Controller=====================================

app.controller("accesoriesCtrl", function ($rootScope,$scope,$http,$localStorage) { 
	$http.get(base_url+"ws/products_json.php?category=1").then(function (response) {
	   $scope.products =response.data;
});
	 $rootScope.qtyIn=function(item){
		 item.qty++;
		 $rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});
		
		 $localStorage.total=$rootScope.total;
	 }
	$rootScope.qtyOut=function(item){
		 item.qty--;
		 if(item.qty<=0)item.qty=1		 
		 $rootScope.total=0;
		 angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		$localStorage.total=$rootScope.total;
	}
	
	if($localStorage.cart==null){
	  $localStorage.cart=[];
	  $localStorage.total=0;
	}
	
	$rootScope.cart=$localStorage.cart; 
	$rootScope.total=$localStorage.total;
	
	 $scope.addItem = function (item) {
		 var id=item.id;
		 var name=item.name;
		 var price=item.new_price;
		 var exists=false;
		
		$rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){
			if(id==value.id){				
				exists=true;
				value.qty++;
			}
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
			$localStorage.total=$rootScope.total;
		});	

		if(!exists){		
		   var json={'id':id,'name':name,'price':price,'qty':1};	     
		   $rootScope.cart.push(json);
		  $rootScope.total+=parseFloat(price);
		  $localStorage.total=$rootScope.total;
		}
    };//end addToCart
	
	$rootScope.deleteItem=function(item){
		var tmp=$rootScope.cart;
		$rootScope.cart=[];
		$rootScope.total=0;
		 angular.forEach(tmp,function(value,key){
			 if(item!=value.id){
				 var json={'id':value.id,'name':value.name,'price':value.price,'qty':value.qty};
				$rootScope.cart.push(json);				
				$rootScope.total+=parseFloat(value.price*value.qty);
			 }
		 });
		 $localStorage.cart=$rootScope.cart;
		 $localStorage.total=$rootScope.total;
	};//DeleteFromCart
});

//=====================End Accesories Controller=======================================



//=====================Start Electronics Controller====================================

app.controller("electronicsCtrl", function ($rootScope,$scope,$http,$localStorage) { 
	  $http.get(base_url+"ws/products_json.php?category=2").then(function (response) {
	   $scope.products =response.data;
});
	 $rootScope.qtyIn=function(item){
		 item.qty++;
		 $rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		 $localStorage.total=$rootScope.total;
	 }
	$rootScope.qtyOut=function(item){
		 item.qty--;
		 if(item.qty<=0)item.qty=1		 
		 $rootScope.total=0;
		 angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		$localStorage.total=$rootScope.total;
	}
	if($localStorage.cart==null){
	  $localStorage.cart=[];
	  $localStorage.total=0;
	}
	$rootScope.cart=$localStorage.cart; 
	$rootScope.total=$localStorage.total;
	 $scope.addItem = function (item) {
		 var id=item.id;
		 var name=item.name;
		 var price=item.new_price;     
		 var exists=false;
		
		$rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){		
			if(id==value.id){				
				exists=true;
				value.qty++;				
			}
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
			$localStorage.total=$rootScope.total;
		});	
			
		if(!exists){		
		   var json={'id':id,'name':name,'price':price,'qty':1};	     
		   $rootScope.cart.push(json);
		  $rootScope.total+=parseFloat(price);
		  $localStorage.total=$rootScope.total;
		}
    };//end addToCart
	
	$rootScope.deleteItem=function(item){
		var tmp=$rootScope.cart;
		$rootScope.cart=[];
		$rootScope.total=0;
		 angular.forEach(tmp,function(value,key){ 
			 if(item!=value.id){
				 var json={'id':value.id,'name':value.name,'price':value.price,'qty':value.qty};
				$rootScope.cart.push(json);				
				$rootScope.total+=parseFloat(value.price*value.qty);
			 }
		 });
		 $localStorage.cart=$rootScope.cart;
		 $localStorage.total=$rootScope.total;
	};//DeleteFromCart
});
//=====================End Electronics Controller====================================


//=====================Start Electronics Controller====================================

app.controller("othersCtrl", function ($rootScope,$scope,$http,$localStorage) { 
	  $http.get(base_url+"ws/products_json.php?category=3").then(function (response) {
	   $scope.products =response.data;
});
	 $rootScope.qtyIn=function(item){
		 item.qty++;
		 $rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		 $localStorage.total=$rootScope.total;
	 }
	$rootScope.qtyOut=function(item){
		 item.qty--;
		 if(item.qty<=0)item.qty=1		 
		 $rootScope.total=0;
		 angular.forEach($rootScope.cart,function(value,key){
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
		});	
		$localStorage.total=$rootScope.total;
	}
	if($localStorage.cart==null){
	  $localStorage.cart=[];
	  $localStorage.total=0;
	}
	$rootScope.cart=$localStorage.cart; 
	$rootScope.total=$localStorage.total;
	 $scope.addItem = function (item) {
		 var id=item.id;
		 var name=item.name;
		 var price=item.new_price;     
		 var exists=false;
		
		$rootScope.total=0;
        angular.forEach($rootScope.cart,function(value,key){		
			if(id==value.id){				
				exists=true;
				value.qty++;				
			}
			$rootScope.total+=parseFloat(value.price)*parseFloat(value.qty);
			$localStorage.total=$rootScope.total;
		});	
			
		if(!exists){		
		   var json={'id':id,'name':name,'price':price,'qty':1};	     
		   $rootScope.cart.push(json);
		  $rootScope.total+=parseFloat(price);
		  $localStorage.total=$rootScope.total;
		}
    };//end addToCart
	
	$rootScope.deleteItem=function(item){
		var tmp=$rootScope.cart;
		$rootScope.cart=[];
		$rootScope.total=0;
		 angular.forEach(tmp,function(value,key){ 
			 if(item!=value.id){
				 var json={'id':value.id,'name':value.name,'price':value.price,'qty':value.qty};
				$rootScope.cart.push(json);				
				$rootScope.total+=parseFloat(value.price*value.qty);
			 }
		 });
		 $localStorage.cart=$rootScope.cart;
		 $localStorage.total=$rootScope.total;
	};//DeleteFromCart
});
//=====================End Others Controller====================================

app.controller('contactUsCtrl', function($scope) {  

 
    
});


app.controller('cartCtrl', function($scope) {  

 
    
});
