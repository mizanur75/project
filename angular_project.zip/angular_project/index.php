<?php
require_once("config.php");
?>
<!doctype html>
<html ng-app="myApp">
<head>
<meta charset="utf-8">
<title>{{title}}</title>
<script src="js/angular.min.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/ngStorage.js"></script>
<script src="js/angular-route.min.js"></script>  
<script src="http://thecodeplayer.com/uploads/js/prefixfree.js"></script> 
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/cart.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
 .material-icons 
</style>
</head>
<body ng-init="cart=[];total=0">

<div class="container">

        <div class="row" style="padding: 10px 0px;">
            <div class="col-md-3" style="color: #EA0000;">
                <h1>Online <span style="color: #006400;">Shop</span></h1>
                <p>Welcome to Online Shop</p>
                <b id="time"></b>
                <button onClick="like()">Like</button><span id="show"></span>
            </div>
            <div class="col-md-9">
                <?php include("pages/carousel.php");?>
            </div>
        </div>


       <div class="row">
         <div class="col-md-12">
            <?php
            include("pages/top_menu.php");
            ?>
         </div>
       </div>
   

     
   <div class="row" style="margin-top: 10px; min-height: 550px;">
     <div class="col-md-2">
      <?php include("pages/side_menu.php");?>
     </div>
      <div class="col-md-10">
            <div>
                <a href="#" class="fa fa-facebook"></a>
                <a href="#" class="fa fa-twitter"></a>
                <a href="#" class="fa fa-google"></a>
                <a href="#" class="fa fa-youtube"></a>
                <a href="#" class="fa fa-pinterest"></a>
            </div>
            
            
         <!--======Placeholder=======-->   
        <div ng-view>
        </div> 
        <!--======Placeholder=======-->   
      </div>    
  </div><!--end row-->
  
  	<div class="row">
    	<div class="col-md-12 news">
            <?php include("pages/news.php"); ?>
        </div>
    </div>
    
  
    <div class="row">
        <div class="col-md-12" style="text-align:center; margin-top:20px;">Project Developed By <a href="http://www.facebook.com/mizanur.ccr">Mizanur Rahman</a><br>Copy Wright&copy 2017
        </div>
    </div>
  
</div><!--end container-->

<script>
	var like = 0;
	function like(){
		document.getElementById("show").innerHTML=like;
		like=like+1;
	}
	function myTimer(){
		var d = new Date();
		var t = d.toLocaleTimeString();
		document.getElementById("time").innerHTML = t;
	}
	setInterval(function(){
		myTimer()
	});
</script>

<script src="app.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>