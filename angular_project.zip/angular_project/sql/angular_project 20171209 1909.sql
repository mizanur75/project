-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.28-MariaDB


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema angular_project
--

CREATE DATABASE IF NOT EXISTS angular_project;
USE angular_project;

--
-- Definition of table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`,`name`) VALUES 
 (1,'Accesories'),
 (2,'Electronics'),
 (3,'Others');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Definition of table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE `order_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `qty` double NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` (`id`,`order_id`,`item_id`,`qty`,`price`) VALUES 
 (1,2,0,0,0),
 (2,0,0,0,0),
 (3,0,0,0,0),
 (4,0,0,0,0),
 (5,0,0,0,0),
 (6,0,0,0,0),
 (7,0,0,0,0),
 (8,0,0,0,0),
 (9,3,0,0,0),
 (10,4,0,0,0),
 (11,5,32,1,699),
 (12,6,1,21,565477),
 (13,6,2,6,78458),
 (14,6,6,3,399);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;


--
-- Definition of table `order_master`
--

DROP TABLE IF EXISTS `order_master`;
CREATE TABLE `order_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  `shipping_address` text,
  `remark` text,
  `order_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_method` varchar(20) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_master`
--

/*!40000 ALTER TABLE `order_master` DISABLE KEYS */;
INSERT INTO `order_master` (`id`,`customer_name`,`shipping_address`,`remark`,`order_datetime`,`payment_method`,`email`,`phone`) VALUES 
 (1,'Jahidul Islam','Rampura','test','2017-12-09 18:32:55','VISA',NULL,''),
 (4,'Mizanur Rahman','Dhaka','Ok','2017-12-11 09:49:01','VISA Card','mizanurrahman615@gmail.com','01710472020'),
 (5,'Nishat','Chittagong','Well','2017-12-11 23:12:03','Master Card',NULL,''),
 (6,'Faruk','Sylhet','test','2017-12-12 09:18:15','VISA Card',NULL,'');
/*!40000 ALTER TABLE `order_master` ENABLE KEYS */;


--
-- Definition of table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `photo` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `new_price` double NOT NULL,
  `old_price` double NOT NULL,
  `uom` varchar(45) NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`,`photo`,`name`,`new_price`,`old_price`,`uom`,`category_id`) VALUES 
 (1,'1.jpg','Aircondition',565477,45465,'piece',2),
 (2,'2.jpg','Red Aircondition',78458,78676,'piece',2),
 (4,'4.jpg','Aircooler',5677,5634,'piece',2),
 (6,'6.jpg','Headphone',399,440,'piece',1),
 (7,'7.jpg','Headphone',430,450,'piece',1),
 (8,'8.jpg','Headphone',430,460,'piece',1),
 (9,'9.jpg','Belt',650,675,'piece',3),
 (10,'10.jpg','Keyboard',399,440,'piece',1),
 (11,'11.jpg','Keyboard',430,440,'piece',1),
 (12,'12.jpg','Keyboard',430,450,'piece',1),
 (13,'13.jpg','Refrigerator',635356,435677,'piece',2),
 (14,'14.jpg','Refrigerator',635356,435677,'piece',2),
 (15,'15.jpg','Mouse',430,450,'piece',1),
 (16,'16.jpg','Mouse',430,460,'piece',1),
 (17,'17.jpg','Mouse',399,440,'piece',1),
 (18,'18.jpg','Iron Machine',1150,1200,'piece',2),
 (19,'19.jpg','Router',1100,1200,'piece',1),
 (20,'20.jpg','Router',1150,1250,'piece',1),
 (21,'21.jpg','Iron Machine',1250,1350,'piece',2),
 (22,'22.jpg','LED Bulb',220,250,'piece',2),
 (23,'23.jpg','Solar System',12200,12500,'piece',2),
 (24,'24.jpg','LED Telivission',8350,8550,'piece',2),
 (25,'25.jpg','Bluetooth Speaker',1650,1750,'piece',1),
 (26,'26.jpg','USB Speaker',599,650,'piece',1),
 (27,'27.jpg','USB Speaker',499,550,'piece',1),
 (28,'28.jpg','LED Telivission',4990,5200,'piece',2),
 (29,'29.jpg','Gents Sunglass',499,550,'piece',3),
 (30,'30.jpg','Gents Sunglass',420,450,'piece',3),
 (31,'31.jpg','Gents Walet',699,750,'gm',3),
 (32,'32.jpg','Gents Walet',699,750,'piece',3),
 (33,'33.jpg','Gents Walet',499,550,'piece',3),
 (34,'34.jpg','Gents Watch',699,750,'piece',3),
 (35,'35.jpg','Gents Watch',699,750,'piece',3);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;


--
-- Definition of table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`,`name`) VALUES 
 (2,'Admin'),
 (3,'User');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;


--
-- Definition of table `subscriber`
--

DROP TABLE IF EXISTS `subscriber`;
CREATE TABLE `subscriber` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mail` varchar(45) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriber`
--

/*!40000 ALTER TABLE `subscriber` DISABLE KEYS */;
INSERT INTO `subscriber` (`id`,`mail`,`date`) VALUES 
 (1,'mail@mail.com','0000-00-00 00:00:00'),
 (2,'masud@mail.com','0000-00-00 00:00:00'),
 (6,'kachu@gmail.com','2017-12-10 12:41:58');
/*!40000 ALTER TABLE `subscriber` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`,`username`,`password`,`inactive`,`role_id`) VALUES 
 (11,'mizanur','e10adc3949ba59abbe56e057f20f883e',0,2),
 (12,'mizan','c20ad4d76fe97759aa27a0c99bff6710',0,2),
 (13,'hfgh','3c59dc048e8850243be8079a5c74d079',0,3);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
