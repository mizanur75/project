<?php

  if(isset($_POST["btnSubmit"])){
	  
	  $category_id=$_POST["cmbCategoryId"];
	  $name=$_POST["txtProductName"];
	  $old_price=$_POST["txtOldPrice"];
	  $new_price=$_POST["txtNewPrice"];
	  $uom=$_POST["cmbUoM"];
	  
	  $photo_tmp=$_FILES["file"]["tmp_name"];
	  $photo_name=$_FILES["file"]["name"];
	 
	  $photo_loc="../img/";
	  
	  $db->query("insert into products(name,old_price,new_price,uom,category_id,photo)values('$name','$old_price','$new_price','$uom','$category_id','')");
	  
	   copy($photo_tmp,$photo_loc.$db->insert_id.".jpg");
	   
	  $db->query("update products set photo='$db->insert_id.jpg' where id='$db->insert_id'");
	  
	 
	  
	  
	  echo "Success";
	  
	  
	  
  }

?>
<div class="row">
	<div class="col-md-4">
        <form action="#" method="post" enctype="multipart/form-data">
              <div>
               Photo<br/>
               <input type="file" name="file" />
             </div>
             <div class="form-group">Category<br/>
               <select class="form-control" name="cmbCategoryId">
                 <?php
                   $cate_table=$db->query("select id,name from category");
                   while(list($id,$name)=$cate_table->fetch_row()){
                       echo "<option value='$id'>$name</option>";
                    }
                 
                 ?>
               </select>
             </div>
             <div class="form-group">
                Product Name<br/>
                <input class="form-control" type="text" name="txtProductName" />
             </div>
             <div class="form-group">
                Old Price<br/>
                <input class="form-control" type="text" name="txtOldPrice" />
             </div>
             <div class="form-group">
                New Price<br/>
                <input class="form-control" type="text" name="txtNewPrice" />
             </div>
             <div class="form-group">
             UoM<br/>
               <select class="form-control" name="cmbUoM">
                 <option value="kg">Kg</option>
                 <option value="piece">Piece</option>
                 <option value="gm">Gm</option>
               </select>
             </div>
             <br/>
             <div>
             <button type="submit" class="btn btn-success" name="btnSubmit">Submit</button>
             </div>
             
         </form>
    </div>
</div>