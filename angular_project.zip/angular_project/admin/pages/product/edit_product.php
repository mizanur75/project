<?php

  if(isset($_POST["btnUpdate"])){
	  
	  $id=$_POST["txtId"];	  
	  $category_id=$_POST["cmbCategoryId"];
	  $name=$_POST["txtProductName"];
	  $old_price=$_POST["txtOldPrice"];
	  $new_price=$_POST["txtNewPrice"];
	  $uom=$_POST["cmbUoM"];
	  
	  $photo_tmp=$_FILES["file"]["tmp_name"];
	  $photo_name=$_FILES["file"]["name"];
	 
	  $photo_loc="../img/";
	  
	  $db->query("update products set name='$name',old_price='$old_price',new_price='$new_price',uom='$uom',category_id='$category_id',photo='$id.jpg' where id='$id'");
	  
	   
	   copy($photo_tmp,$photo_loc.$id.".jpg");
	   
	 	  
	  
	  echo "Success Updated";
	  
  }
  
  
  if(isset($_POST["btnEdit"])){
	  $id=$_POST["txtId"];
	  
	  $product_tbl=$db->query("select name,old_price,new_price,uom,category_id,photo from products where id='$id'");
	  
	  
	  list($pname,$old_price,$new_price,$uom,$category_id,$photo)=$product_tbl->fetch_row();
	}
  

?>
<div class="row">

	<div class="col-md-4">
      <form action="#" method="post" enctype="multipart/form-data">
          <div class="form-group">ID<br/>
          <input class="form-control" type="text" name="txtId" value="<?php echo $id?>" readonly />
          </div>
          <div class="form-group">Category<br/>
           
           <select class="form-control" name="cmbCategoryId">
             <?php
               $cate_table=$db->query("select id,name from category");
               while(list($cid,$name)=$cate_table->fetch_row()){
                
                  if($cid==$category_id){
                    echo "<option value='$cid' selected>$name</option>";
                  }else{
                    echo "<option value='$cid'>$name</option>";
                  }
                
                }
             
             ?>
           </select>
         </div>
         <div class="form-group">
            Product Name<br/>
            <input class="form-control" type="text" name="txtProductName" value="<?php echo isset($pname)?$pname:""?>" />
         </div>
         <div class="form-group">
            Old Price<br/>
            <input class="form-control" type="text" name="txtOldPrice" value="<?php echo isset($old_price)?$old_price:""?>" />
         </div>
         <div class="form-group">
            New Price<br/>
            <input class="form-control" type="text" name="txtNewPrice" value="<?php echo isset($new_price)?$new_price:""?>" />
         </div>
         <div class="form-group">
         UoM<br/>
           <select class="form-control" name="cmbUoM">
             <option value="kg">Kg</option>
             <option value="piece">Piece</option>
             <option value="gm">Gm</option>
           </select>
         </div>
         <div>
          <?php 
          
            if(isset($photo)){
              echo "<img src='../img/$photo' />";	
            }
          
          ?>
          
           Photo<br/>
           <input type="file" name="file"  />
         </div>
         <br/>
         <div>
         <button type="submit" class="btn btn-success" name="btnUpdate">Update</button>
         </div>
         
        </form>
    </div>

</div>