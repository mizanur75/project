
<?php
	$db=new mysqli("localhost","root","","angular_project");
	
	if(isset($_POST["btnSubmit"])){
		
		$mail=$_POST["txtMail"];
		
		$db->query("insert into subscriber(mail)values('$mail')");
		
		echo "Success";
	}
	
?>


<nav class="navbar navbar-expand-lg navbar-light bg-danger">
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav mr-auto">
	<button class="btn btn-outline-success my-2 my-sm-0" style="background-color:#000; color:#FFF; margin:0px 10px 0px 185px;">Get News For Update</button>
    <form class="form-inline my-2 my-lg-0" action="#" method="post">
      <input class="form-control mr-sm-2" type="text" name="txtMail" placeholder="Input Email" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="btnSubmit">Submit</button>
    </form>
   </ul>
  </div>
</nav>