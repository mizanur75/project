<?php
	if(isset($_POST["btnDelete"])){
		  $subs_id=$_POST["txtId"];
		  
		  $db->query("delete from subscriber where id='$subs_id'");
		  echo "Deleted";
		  
	}
	
	
	$test = $db->query("select id,mail,date from subscriber");
	echo "<table class='table'>";
	echo "<tr><th>Id</th><th>Mail</th><th>Date</th><th>Delete</th></tr>";
	while(list($id,$mail,$date)=$test->fetch_row()){
		
		$date=date("d M y h:i A",strtotime($date));
		
		echo "<tr><td>$id</td><td>$mail</td><td>$date</td><td><form action='home.php?page=12' method='post' style='display:inline' onsubmit='return confirm(\"Are you sure?\")'><input type='hidden' name='txtId' value='$id' /><input type='submit' name='btnDelete' class='material-icons red600' value='delete'></form></td></tr>";
	}
	echo "</table>";
?>