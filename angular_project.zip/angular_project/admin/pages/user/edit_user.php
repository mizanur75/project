<?php

  if(isset($_POST["btnUpdate"])){
	  
	  $user_id=$_POST["txtId"];
	  $role_id=$_POST["cmbRoleId"];
	  $username=$_POST["txtUsername"];
	  $password=md5(trim($_POST["txtPassword"]));
	  $repassword=md5(trim($_POST["txtRePassword"]));
	  
	  if($password==$repassword){
	  
	  $db->query("update user set username='$username' where id='$user_id'");
	  
	  echo "Successfully updated";
	  
	  }else{
		echo "password uporar shathe melanai";  
	   }
	  
  }
  
  
  if(isset($_POST["btnEdit"])){
	  $id=$_POST["txtId"];
	  
	  $user=$db->query("select username,password,role_id,inactive from user where id='$id'");
	  
	  list($username,$password,$role_id,$inactive)=$user->fetch_row();
	  
	  
	}
  

?>
<div class="row">
	<div class="col-md-4">
    <form action="#" method="post" onSubmit="return confirm('Are you sure?')">
      <div class="form-group">
        <label>Id</label>
        <input class="form-control" type="text" name="txtId" value="<?php echo isset($id)?$id:""?>" />
     </div>
     <div class="form-group">
     <label>Role</label>
       <select name="cmbRoleId" class="form-control">
         <?php
           $role_table=$db->query("select id,name from role");
           while(list($id,$name)=$role_table->fetch_row()){
               echo "<option value='$id'>$name</option>";
            }
         
         ?>
       </select>
     </div>
     <div class="form-group">
        <label>Username</label>
        <input type="text" class="form-control" name="txtUsername" value="<?php echo isset($username)?$username:""?>" />
     </div>
     <div class="form-group">
        <label>Password</label>
        <input type="password" class="form-control" name="txtPassword" />
     </div>
     <div class="form-group">
        <label>Retype Password</label>
        <input type="password" class="form-control" name="txtRePassword" />
     </div>
     <div class="form-group">
     <button type="submit" class="btn btn-success" name="btnUpdate">Update</button>
     </div>
     
    </form>
    </div>
</div>