<?php

  if(isset($_POST["btnSubmit"])){
	  
	  $role_id=$_POST["cmbRoleId"];
	  $username=$_POST["txtUsername"];
	  $password=md5(trim($_POST["txtPassword"]));
	  $repassword=md5(trim($_POST["txtRePassword"]));
	  
	  if($password==$repassword){
	  
	  $db->query("insert into user(username,password,role_id,inactive)values('$username','$password','$role_id',0)");
	  
	  echo "Success";
	  
	  }else{
		echo "password uporar shathe melanai";  
	   }
	  
  }

?>
<div class="row">
	<div class="col-md-4">
        <form action="#" method="post">
             <div class="form-group">
             <label>Role</label>
               <select name="cmbRoleId" class="form-control">
                 <?php
                   $role_table=$db->query("select id,name from role");
                   while(list($id,$name)=$role_table->fetch_row()){
                       echo "<option value='$id'>$name</option>";
                    }
                 
                 ?>
               </select>
             </div>
             <div class="form-group">
               <label>Username</label>
                <input type="text" class="form-control" name="txtUsername" />
             </div>
             <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="txtPassword" />
             </div>
             <div class="form-group">
                <label>Retype Password</label>
                <input type="password" class="form-control" name="txtRePassword" />
             </div>
             <div class="form-group">
             <button type="submit" class="btn btn-success" name="btnSubmit">Save</button>
             </div>
     
        </form>
    </div>
</div>