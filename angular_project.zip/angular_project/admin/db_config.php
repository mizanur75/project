<?php
 $db=new mysqli("localhost","root","","angular_project");
?>