<?php
   
   if(isset($_GET["page"])){
	   $page=$_GET["page"];
	   
	   if($page==1){
		   
		 include("pages/contact/add_contact.php"); 
		   
	   }else if($page==2){
		   
	   }else if($page==3){
		   
		   //include("pages/contact/view_contact.php");
		   include("pages/user/edit_user.php");
		  
	   }else if($page==4){
		   
		   include("pages/user/add_user.php");
		  
	   }else if($page==5){
		   
		   include("pages/user/manage_user.php");
		  
	   }else if($page==6){
		   
		   include("pages/user/view_user.php");
		  
	   }else if($page==7){
		   
		    include("pages/product/add_product.php");
		  
	   }else if($page==8){
		   
		    include("pages/product/manage_product.php");
		  
	   }else if($page==9){
		   
		    include("pages/product/view_products.php");
		  
	   }else if($page==10){
		   
		    include("pages/product/edit_product.php");
		  
	   }else if($page==11){
		   
		    include("pages/order/view_orders.php");
		  
	   }else if($page==12){
		   
		    include("pages/subscriber/subscriber.php");
		  
	   }
	   
   }else{
	   
       echo "Welcome to <h1 style='color:#6C0000; font-style:italic;'>Admin Pannel</h1>";
   }

?>