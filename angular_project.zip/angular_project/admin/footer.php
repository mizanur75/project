 <footer class="footer">
      <div class="container">
        <span class="text-muted">Copyright&copy;2017</span>
      </div>
    </footer>