<?php
$db=new mysqli("localhost","root","","mizan");
?>